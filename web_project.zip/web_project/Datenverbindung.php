<?php

$dsn = "mysql:dbhost=localhost;dbname=u-rw038";
$dbuser = "rw038";
$dbpass = "Oleinge8ro";
$db = new PDO ($dsn, $dbuser, $dbpass);

?>