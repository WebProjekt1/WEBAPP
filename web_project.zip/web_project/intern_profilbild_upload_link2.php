<div class="container">
    <div class="row">
        <div class="col-md-12">
            <p class="header-2">PROFILBILD ÄNDERN</p>
        </div>
    </div>
    <br>
    <br>
<html>
<body>


   <form class="formular2" action="?seite=intern_profilbild_upload" method="post" enctype="multipart/form-data">
       <input type="file" name="Bilddatei" id="Bilddatei"><br>
      <input class="btn btn-default" type="submit" value="Neues Profilbild hochladen" name="submit">
   </form>



</body>
</html>
</div>