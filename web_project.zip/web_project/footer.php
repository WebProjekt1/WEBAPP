<?php

?>

<footer>
        <a class="links" href="?seite=impressum">Impressum</a>
</footer>