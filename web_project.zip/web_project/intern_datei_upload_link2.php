<html>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <p class="header-2">NEUE DATEI HOCHLADEN</p>
        </div>
    </div>
    <br>
    <br>
<form class="formular2" action="?seite=intern_datei_upload" method="post" enctype="multipart/form-data">
    <input type="hidden" name="sent" value="1">
    <input type="file" name="Datei" id="Datei"><br>
    <input class="btn btn-default" type="submit" value= "Hochladen" name="submit"> &nbsp;&nbsp;
    <input class="btn btn-default" type="Reset" value="Zurücksetzen">
</form>
</div>
</html>