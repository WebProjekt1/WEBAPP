<div class="container">
    <div class="textstandard">


<?php


session_destroy();

echo "Der Logout war erfolgreich";
?>
    </div>
</div>

