<div class="container">
    <div class="row">
        <div class="col-md-12">
            <p class="header-2">IMPRESSUM</p>
        </div>
    </div>
    <br>
    <div class="impressum">
    <h2>yourBox</h2> <br>
    <h4>Adresse</h4>
    Hochschule der Medien <br>
    Nobelstraße 10 <br>
    70569 Stuttgart <br>
    <h4>Kontakt</h4>
        Telefon: 0711 8923 10 (Zentrale) <br>
        Telefax: 0711 8923 11 <br><br>

    <h4>Alle Angaben gemäß TMG §5</h4>

    </div>


</div>